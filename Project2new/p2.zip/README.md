run ./install.sh
- if there is an permission error 
- run chmod +x install.sh

reboot system and choose (2) Start Custum MINIX 3

to run test
- ./cpu
- ./io